public class WeekExcotion extends Exception{
    public WeekExcotion(){
        System.out.println("不符合输入要求！");
    }
}
