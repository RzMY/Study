public class Test03 {
    public static void main(String[] args){
        Animal a = new Animal();
        Rabbit r = new Rabbit();
        Tiger t = new Tiger();
        a.eat();
        a.sleep();
        r.eat();
        r.sleep();
        t.eat();
        t.sleep();
    }
}
