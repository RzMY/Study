public class Animal {
    void eat(){
        System.out.println("food!");
    }
    void sleep(){
        System.out.println("sleep!");
    }
}
