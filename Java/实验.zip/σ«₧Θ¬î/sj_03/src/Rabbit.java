public class Rabbit extends Animal{
    void eat(){
        System.out.println("我是兔子，我吃草！");
    }
}
        