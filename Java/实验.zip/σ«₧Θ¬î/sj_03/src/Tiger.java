public class Tiger extends Animal{
    void eat(){
        System.out.println("我是老虎，我吃肉！");
    }
}
